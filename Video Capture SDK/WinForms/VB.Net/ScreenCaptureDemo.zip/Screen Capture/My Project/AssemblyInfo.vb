﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("VF SDK VB.NET Screen Capture Demo")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("virtualAC4")> 
<Assembly: AssemblyProduct("VF SDK VB.NET Screen Capture Demo")> 
<Assembly: AssemblyCopyright("Copyright © virtualAC4 2009")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("d5cae5f0-5da4-46fd-b722-8a1ffd318eef")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("11.0.59.0")>
<Assembly: AssemblyFileVersion("11.0.59.0")>
